^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package autoware_map_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.13.0 (2019-12-03)
-------------------
* Update package.xml files to Format 2.
* Contributors: Joshua Whitley

1.12.0 (2019-07-12)
-------------------
* Adding CHANGELOG for autoware_external_msgs and autoware_map_msgs.
* Updating autoware_map_msgs version for ROS release.
* Merge branch 'fix/remove_unnecessary_depend' into 'master'
  Removing unused depend in autoware_map_msgs.
  See merge request autowarefoundation/autoware.ai/messages!4
* Removing unused depend in autoware_map_msgs.
* Merge branch 'feature/autoware_map_msgs' into 'master'
  Add autoware_map_msgs package
  See merge request autowarefoundation/autoware.ai/messages!2
* add autoware_map_msgs
  Signed-off-by: mitsudome-r <ryohsuke.mitsudome@tier4.jp>
* Contributors: Abraham Cano, Geoffrey Biggs, Joshua Whitley, mitsudome-r
