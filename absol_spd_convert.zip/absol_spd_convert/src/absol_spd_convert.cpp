#include <ros/ros.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <autoware_msgs/DetectedObject.h>
#include <autoware_msgs/DetectedObjectArray.h>
#include <visualization_msgs/Marker.h>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Geometry>

class AbsoluteConvertSpeed {
private:
    ros::NodeHandle nh_;

    ros::Subscriber detected_obj_sub_;
    ros::Subscriber current_pose_sub_;
    ros::Subscriber current_velo_sub_;

    ros::Publisher absol_detected_obj_pub_;
    ros::Publisher obstacle_marker_pub_; // New publisher for markers

    autoware_msgs::DetectedObjectArray absol_obj_array_;

    float cur_vx = 0.0;
    float cur_vy = 0.0;
    float cur_px = 0.0;
    float cur_py = 0.0;

    double cur_qx = 0.0;
    double cur_qy = 0.0;
    double cur_qz = 0.0;
    double cur_qw = 0.0;
    Eigen::Vector3d pt_m;
    Eigen::Matrix4d pt_mat;

public:
    AbsoluteConvertSpeed() {
        // Subscriber
        detected_obj_sub_ = nh_.subscribe("tracking_front/objects", 10, &AbsoluteConvertSpeed::ObjCallback, this);
        current_velo_sub_ = nh_.subscribe("current_velocity", 10, &AbsoluteConvertSpeed::TwistCallback, this);
        current_pose_sub_ = nh_.subscribe("current_pose", 10, &AbsoluteConvertSpeed::PoseCallback, this);
        
        // Publisher
        absol_detected_obj_pub_ = nh_.advertise<autoware_msgs::DetectedObjectArray>("target_objects", 10);
        obstacle_marker_pub_ = nh_.advertise<visualization_msgs::Marker>("obstacle_markers", 10); // Initialize marker publisher
    }

    void ObjCallback(const autoware_msgs::DetectedObjectArray::ConstPtr& msg) {
        absol_obj_array_.header = msg->header;
        absol_obj_array_.objects.clear();
        
        // Prepare marker message
        visualization_msgs::Marker marker;
        marker.header.frame_id = "map"; // Use the correct frame_id
        marker.header.stamp = ros::Time::now();
        marker.ns = "obstacles"; // Namespace for the markers
        marker.id = 0; // Unique ID for the marker
        marker.type = visualization_msgs::Marker::SPHERE; // Type of the marker (sphere)
        marker.action = visualization_msgs::Marker::ADD; // Add a new marker
        marker.scale.x = 0.5; // Size of the marker
        marker.scale.y = 0.5;
        marker.scale.z = 0.5;
        marker.color.a = 1.0; // Marker transparency
        marker.color.r = 1.0; // Red color
        marker.color.g = 0.0;
        marker.color.b = 0.0;

        for (size_t i = 0; i < msg->objects.size(); ++i) {
            autoware_msgs::DetectedObject absol_obj;
            absol_obj = msg->objects[i];
            absol_obj.velocity.linear.x += cur_vx;
            absol_obj.velocity.linear.y += cur_vy;
            
            pt_m = Eigen::Vector3d(cur_px,
                    cur_py, 0);
            double q_x = cur_qx;
            double q_y = cur_qy;
            double q_z = cur_qz;
            double q_w = cur_qw;
            pt_mat << 1 - 2*q_y*q_y - 2*q_z*q_z, 2*q_x*q_y - 2*q_z*q_w, 2*q_x*q_y + 2*q_y*q_w, pt_m(0),
                            2*q_x*q_y + 2*q_z*q_w, 1 - 2*q_x*q_x - 2*q_z*q_z, 2*q_y*q_z + 2*q_x*q_w, pt_m(1),
                            2*q_x*q_z - 2*q_y*q_w, 2*q_y*q_z - 2*q_x*q_w, 1 - 2*q_x*q_x + 2*q_y*q_y, 0,
                            0, 0, 0, 1;

            Eigen::Vector4d local_coords(absol_obj.pose.position.x, absol_obj.pose.position.y, absol_obj.pose.position.z, 1);
            Eigen::Vector4d global_coords = pt_mat * local_coords;

            // Now global_coords contains the obstacle position in global coordinates
            ROS_INFO("Obstacle Global Position: x=%f, y=%f, z=%f", global_coords(0), global_coords(1), global_coords(2));
            absol_obj.pose.position.x = global_coords(0);
            absol_obj.pose.position.y = global_coords(1);
            absol_obj.pose.position.z = global_coords(2);

            absol_obj_array_.objects.push_back(absol_obj);

            // Update marker position for each detected object
            marker.pose.position.x = global_coords(0);
            marker.pose.position.y = global_coords(1);
            marker.pose.position.z = global_coords(2);
            marker.id = i; // Assign a unique ID for each marker
            obstacle_marker_pub_.publish(marker); // Publish the marker
        }

        absol_detected_obj_pub_.publish(absol_obj_array_);
    }

    void TwistCallback(const geometry_msgs::TwistStamped::ConstPtr& msg) {
        cur_vx = msg->twist.linear.x;
        cur_vy = msg->twist.linear.y;
    }

    void PoseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {        
        cur_px = msg->pose.position.x;
        cur_py = msg->pose.position.y;

        cur_qx = msg->pose.orientation.x;
        cur_qy = msg->pose.orientation.y;
        cur_qz = msg->pose.orientation.z;
        cur_qw = msg->pose.orientation.w;
    }
};

int main(int argc, char **argv) {
    ros::init(argc, argv, "absol_spd_convert");

    AbsoluteConvertSpeed subscriber;

    ros::spin();

    return 0;
}
